﻿using UnityEngine;
using System.Collections;

public class PlayerScript : MonoBehaviour {
	public Rigidbody rb; 
	public float speed;
	public bool check;
	public GameObject Key;


	// Use this for initialization
	void Start () {
		rb = GetComponent<Rigidbody> ();
		speed = speed;
		check = false;
		Key = Key;

	}
	
	// Update is called once per frame
	void FixedUpdate () {

		float moveHorizontal = Input.GetAxis ("Horizontal");
		float moveVertical = Input.GetAxis ("Vertical");

		Vector3 movement = new Vector3 (moveHorizontal, 0f, moveVertical);
		rb.velocity = movement * speed;

	}

	void OnTriggerEnter(Collider other){
		if (other.name == "Key") {
			check = true;
			Destroy (Key);
		}
		if (other.name == "Red Wall" && check == true) {
			Application.LoadLevel ("Won");
		}
	}
}
