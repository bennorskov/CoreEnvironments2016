﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class getItem : MonoBehaviour {

	public bool keyItem;

	// Use this for initialization
	void Start () {
		keyItem = false;
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	void OnTriggerEnter(Collider hitInfo){
		if(hitInfo.name == "key"){
			keyItem = true;
			Destroy (hitInfo.gameObject);
		}
		if(hitInfo.name == "doorhandle"){
			if(keyItem){
			keyItem = false;
				Destroy (hitInfo.gameObject.transform.parent.gameObject);
			}
		}
		if(hitInfo.name == "next"){
			SceneManager.LoadScene (1);
		}
	}
}
