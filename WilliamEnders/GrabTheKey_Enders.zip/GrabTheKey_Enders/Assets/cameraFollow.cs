﻿using UnityEngine;
using System.Collections;

public class cameraFollow : MonoBehaviour {

	public Transform player;
	private Vector3 playPos;
	public float distance;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void FixedUpdate () {
		playPos = new Vector3 (player.position.x,player.position.y + distance,player.position.z - distance);
		transform.position = Vector3.Lerp (transform.position,playPos,0.08f);
	}
}
