﻿using UnityEngine;
using System.Collections;

public class playerMove : MonoBehaviour {

	private Rigidbody rb;
	public float speed;
	float moveHorizontal = Input.GetAxis ("Horizontal");
	float moveVertical = Input.GetAxis ("Vertical");

	// Use this for initialization
	void Start () {
		rb = transform.GetComponent<Rigidbody> ();
	
	}
	
	// Update is called once per frame
	void FixedUpdate () {
		Vector3 movement = new Vector3 (moveHorizontal, 0f, moveVertical);
		rb.velocity = movement * speed;
	}
}
