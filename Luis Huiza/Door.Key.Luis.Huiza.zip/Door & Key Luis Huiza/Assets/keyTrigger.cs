﻿using UnityEngine;
using System.Collections;

public class keyTrigger : MonoBehaviour {

	void Start () {
	
	}
	

	void Update () {

	}

	void OnTriggerEnter(Collider other) {

		if (other.tag == "Player") {

			other.GetComponent<PlayerMov>().grabtheKey = true;

			Destroy (gameObject);

		}
	}
}
