﻿using UnityEngine;
using System.Collections;

public class openGate : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	void OnCollisionEnter(Collision Coll) {

		if (Coll.gameObject.tag == "Player") {

			if (Coll.gameObject.GetComponent<PlayerMov> ().grabtheKey == true) {

				Application.LoadLevel("YOU WIN");

			}

		}

	}
}
