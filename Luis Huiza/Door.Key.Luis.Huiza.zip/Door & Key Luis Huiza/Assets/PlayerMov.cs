﻿using UnityEngine;
using System.Collections;

public class PlayerMov : MonoBehaviour {

	public float speed = 3f;
	public bool grabtheKey = false;

	void Start () {
	

	}
	

	void Update () {
	
		if (Input.GetKey (KeyCode.LeftArrow) == true) {

			gameObject.GetComponent<Rigidbody> ().velocity = (new Vector3 (-1, 0, 0) * speed);

		} else if (Input.GetKey (KeyCode.RightArrow) == true) {

			gameObject.GetComponent<Rigidbody> ().velocity = (new Vector3 (1, 0, 0) * speed);

		} else if (Input.GetKey (KeyCode.UpArrow) == true) {
			
			gameObject.GetComponent<Rigidbody> ().velocity = (new Vector3 (0, 0, 1) * speed);

		} else if (Input.GetKey (KeyCode.DownArrow) == true) {
				
			gameObject.GetComponent<Rigidbody> ().velocity = (new Vector3 (0, 0, -1) * speed);
		
		} else {

			gameObject.GetComponent<Rigidbody> ().velocity = (new Vector3 (0, 0, 0) * speed);

		}
	}
}
