﻿using UnityEngine;
using System.Collections;

public class playerScript : MonoBehaviour {

	public bool hasKey;
	private Rigidbody rb;
	public float speed;

	//private Vector3 moveDirection = Vector3.zero;

	// Use this for initialization
	void Start () {
		hasKey = false;
		rb = GetComponent<Rigidbody>();
	}

	void FixedUpdate() {
		float moveHorizontal = Input.GetAxis("Horizontal") * speed;
		float moveVertical = Input.GetAxis("Vertical") * speed;
		Vector3 movement = new Vector3(moveHorizontal, 0.0f, moveVertical).normalized;
		rb.velocity = movement;
	}

	void OnTriggerEnter(Collider other){
		if (other.tag == ("Key")){
			hasKey = true;
		}

			if (other.tag ==("Exit") && hasKey == true){
				Application.LoadLevel ("Scene2");
			}
	}
}
