﻿
using UnityEngine;
using System.Collections;

public class playerControllerCopy : MonoBehaviour {

	//NOTES: 1. fix the Elongate false timer
	// 2. Adjust jump so you're actually going up
	// 3. add button collider bool to open "door" in last area
	// 4. make obstacle with talking NPC / prevents you from moving

	Animator animator;

	public float xSpeed, xScale, speed, timer;
	public KeyCode keyUP,keyDOWN,keyLEFT,keyRIGHT, keyTALK, keyELONGATE, keyJUMP; 
	public float leftLimit, rightLimit;		
	public float jumpHeight;
	private Rigidbody2D rb;
	private bool grounded;
	public Transform groundCheck;
	public float moveForce = 365f;
	public float maxSpeed = 5f;


	[HideInInspector] public bool jump = false;

	//contextual interactions
	public bool isTalking = false;
	public bool isAngry = false;
	public bool isBall = false;
	public bool isLong = false;
	public bool buttonPressed; //move to diff gameObject?




	// Use this for initialization
	void Start () {

		animator = GetComponent<Animator>();
		speed = .3f;
		xScale = transform.localScale.x;
		rb = GetComponent<Rigidbody2D> ();
//		rb = GetComponent<Rigidbody> ();
	
	}
	
	// Update is called once per frame
	void Update () {

		Interact ();
		ColliderRender ();

		if (isAngry == false) {
			Movement ();
		} 


		// if in tunnel/rolling collision, then remove player controls 	

		//if in collision box of NPC, isTalking = true, else false

	}

	void ColliderRender(){
		Renderer renderer = GetComponent<SpriteRenderer>(); // get the sprite's collider size
		Vector3 v = renderer.bounds.size; 
		BoxCollider2D b = GetComponent<Collider2D>() as BoxCollider2D;
		//BoxCollider b = GetComponent<Collider>() as BoxCollider;


		b.size = v;
		//print (b.offset);

		if (isBall) {
			b.offset = new Vector2 (0f, 2f);
		} else if (isLong) {
			b.offset = new Vector2 (-1.5f, 6.5f);
		} else {
			b.offset = new Vector2 (0.0f, 5.1f);
		}
	}


	void Interact () { 

		isLong = false; //I think this needs a timer
		if (isLong == true) { //extending isLong state to fix box

			if (timer < 1.25f) {
				timer += Time.deltaTime; 
			} else {
				isLong = false;
			}
		}

		if (isAngry == true) { //anger (contextual? when character cannot perform action?)

			if (timer < 2.5f) {
				timer += Time.deltaTime; 
			} else {
				isAngry = false;
				animator.SetBool ("changeFace", false);
			}
		}

		//Talking
		if (Input.GetKey(keyTALK)) {// make gamepad button
			if (isTalking == true) { 
				animator.SetBool ("talk", true);
			} else {
				isAngry = true; //if press button outside of correct collision, angryface
				animator.SetBool ("changeFace", true);
				timer = 0f;
			}
		}else {
			animator.SetBool ("talk", false);
		}



		//ELONGATE
		if (Input.GetKey(keyELONGATE)) { //make buttonPressed true if within collision box. Make gamepad button
			animator.SetBool ("elongate", true);
			isLong = true;


		}else {
			animator.SetBool ("elongate", false);


		}


	
	}

	void OnTriggerStay2D(Collider2D other){
		//Debug.Log("talk available");

		if (other.tag == ("npc")){
		if (Input.GetKey (keyTALK) && other.tag == ("npc")) {
			isTalking = true;
		} else {
			isTalking = false;
		}
	}
	}

	void OnTriggerExit2D(Collider2D other){
		isTalking = false;

	}


	void Movement () { 

		if (Input.GetKey (keyLEFT) || Input.GetKey (keyRIGHT)) { 
			//MOVEMENT LEFT
			if (Input.GetKey (keyLEFT)) { 

				if (isBall == true) {  
					animator.SetBool ("roll", true);
				} else {
					animator.SetBool ("walk", true);
				}

				transform.localScale = new Vector3 (xScale, transform.localScale.y, transform.localScale.z);
		

				if (transform.position.x >= leftLimit) {
					transform.Translate (Vector2.left * speed);
					Debug.Log ("Moving Left");
				} else {
					Debug.Log (transform.position.x + ">=" + leftLimit);
				}
			}

			//MOVEMENT RIGHT
			if (Input.GetKey (keyRIGHT)) { 

				if (isBall == true) {  
					animator.SetBool ("roll", true);
				} else {
					animator.SetBool ("walk", true);
				}
				transform.localScale = new Vector3 (-xScale, transform.localScale.y, transform.localScale.z);

				if (transform.position.x <= rightLimit) {
					transform.Translate (Vector2.right * speed);
					Debug.Log ("Moving Right");
				} else {
					Debug.Log (transform.position.x + "<=" + rightLimit);
				}
			}

		} else {
			animator.SetBool ("walk", false);
			animator.SetBool ("roll", false);
		}



		//JUMPING --> MUST ADD CONSTRAINTS, NO OTHER BUTTONS PRESSABLE, ADD TRANSLATE
		//grounded = Physics2D.Linecast (transform.position, groundCheck.position, 1 << LayerMask.NameToLayer ("Ground"));

		float h = Input.GetAxis ("Horizontal");



		if (Input.GetKey (keyJUMP)) { //set to SPACE on kb + gamepad button //&& grounded
			animator.SetBool ("jump", true);
			rb.AddForce (new Vector2 (0f, jumpHeight));
			jump = true;

			if (h * rb.velocity.x < maxSpeed)
				rb.AddForce (Vector2.right * h * moveForce);

			if (Mathf.Abs (rb.velocity.x) > maxSpeed)
				rb.velocity = new Vector2(Mathf.Sign (rb.velocity.x) * maxSpeed, rb.velocity.y);
		} else {
			animator.SetBool ("jump", false);
			jump = false;

		}
			

		//ROLLING
		if (Input.GetKey (keyDOWN)) { //turns into ball + make gamepad button
			animator.SetBool ("transform1", true);
			isBall = true;
		} else {
			animator.SetBool ("transform1", false);

		}
			
		if (Input.GetKey (keyUP) && isBall == true) { //transform back from ball + ADD OTHER BUTTONS?
			animator.SetBool ("transform2", true);
			isBall = false;
		} else {
			animator.SetBool ("transform2", false);

		}
	}

}

