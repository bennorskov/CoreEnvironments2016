﻿using UnityEngine;
using System.Collections;

public class npcController : MonoBehaviour {

	//NOTES: 1. make npc talk when spoken to

	Animator animator;
	private bool hasTalked = false;
	private bool isTalking;
	public GameObject playerObject;
	Animator playerAnimator;
	public GameObject talkObstacle;


	// Use this for initialization
	void Start () {
		animator = GetComponent<Animator>();
		playerAnimator = playerObject.GetComponent<Animator> ();

		//GameObject Player = GameObject.Find ("Player");
		//anim = Player.GetComponent<Animator>();
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	void OnTriggerStay2D(Collider2D other){
		//Debug.Log("talk available");

		//playerObject = other.gameObject;
		isTalking = playerAnimator.GetBool ("talk");

		if (other.tag == ("Player")){ //Make it so only awakens when player TALKS?  && isTalking == true
				animator.SetBool ("isTired", true);

			if (isTalking == true) {
				hasTalked = true;
				animator.SetBool ("NPCisTalking", true);
			} else {
				animator.SetBool ("NPCisTalking", false);
			}

			if (hasTalked == true) {
				//animator.SetBool ("isAwake", true);
				//destroy child object -> collider
				//talkObstacle = this.gameObject.transform.GetChild(0);
				Destroy(talkObstacle);
			}

		} else {
			animator.SetBool ("isTired", false);
		}




	}

	void OnTriggerExit2D(Collider2D other){

		if (hasTalked == true) {
		animator.SetBool ("isAwake", true);
		}
	}
}
