﻿using UnityEngine;
using System.Collections;

public class PlayerController : MonoBehaviour {

	private float speed;
	private float xSpeed;
	private Animator animator;
	private Vector3 scale;

	void Start () {

		speed = 5f;
		animator = GetComponent<Animator> ();
		scale = transform.localScale;
	}

	void Update () {
		
		xSpeed = Input.GetAxis ("Horizontal") * speed * Time.deltaTime;

		transform.Translate (Vector3.forward * xSpeed);


		if (Input.GetKey (KeyCode.LeftArrow)) {

			transform.localScale = new Vector3(-scale.x,scale.y,scale.z);


			transform.Translate (Vector3.left * speed * Time.deltaTime);

		}

		if (Input.GetKey (KeyCode.RightArrow)) {
			
			transform.localScale = scale;

			transform.Translate (Vector3.right * speed * Time.deltaTime);

		}

		if (Input.GetKey("1")) {
			animator.SetBool ("Walk", true);
		} else {
			animator.SetBool ("Walk", false);
		}
}

}