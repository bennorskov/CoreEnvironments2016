﻿using UnityEngine;
using System.Collections;

public class animatorMove : MonoBehaviour {



		void OnAnimatorMove() {
			Animator animator = GetComponent<Animator>();
		if (animator) {
			Vector3 newPosition = transform.parent.position;
			newPosition.y += animator.deltaPosition.y;
			newPosition.x += animator.deltaPosition.x;
			transform.parent.position = newPosition;
		}
		}
	}
