﻿using UnityEngine;
using System.Collections;

public class pMov : MonoBehaviour {

	public float speed;
	public bool hasKey;

	// Use this for initialization
	void Start () {

		hasKey = false;
	
	}

	// Update is called once per frame
	void FixedUpdate () {

		float movex = 0f;
		float movey = 0f;
		movex = Input.GetAxis ("Horizontal");
		movey = Input.GetAxis ("Vertical");

		GetComponent<Rigidbody2D> ().velocity = new Vector2 (movex * speed, movey * speed);

	}

	void OnTriggerEnter2D(Collider2D other) {
		if (other.CompareTag ("Key")) {
			hasKey = true;
			Destroy (other.gameObject);


			//////////////////////////
			GameObject.Find ("KeySound").GetComponent<AudioSource> ().Play ();
			//////////////////////////

		}

		if (other.CompareTag ("Door") && hasKey == true){
			Destroy (other.gameObject);


			//////////////////////////
			GameObject.Find ("DoorSound").GetComponent<AudioSource> ().Play ();
			//////////////////////////

		}

		if (other.CompareTag ("Finish")) {
			Application.LoadLevel ("EndScene");
		}
	}
		
}
