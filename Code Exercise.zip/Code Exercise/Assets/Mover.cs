﻿using UnityEngine;
using System.Collections;

public class Mover : MonoBehaviour {

	public Rigidbody rb;
	public bool hasKey = false;

	void Start () {

		rb = GetComponent<Rigidbody> ();
	
	}

	void FixedUpdate () {

		float moveHorizontally = Input.GetAxis ("Horizontal");
		float moveVertically = Input.GetAxis ("Vertical");

		rb.velocity = new Vector3 (moveHorizontally * 10, 0, moveVertically * 10);

	}

	 void OnTriggerEnter(Collider other){
		
		if (other.gameObject.CompareTag ("key")){

			hasKey = true;
			Destroy (other.gameObject);
		}

		if (other.gameObject.CompareTag ("door") && hasKey){
			
			Application.LoadLevel ("Scene 2");
		}
	} 
		
}
